<template>
  <v-container fluid class="fondo_cont">
    <div class="div-container">
      <iframe
        width="1000"
        height="500"
        src="https://www.youtube.com/embed/O9_swe1z9yY?controls=0"
        frameborder="0"
        allowfullscreen
      ></iframe>
    </div>
  </v-container>
</template>

<script>
export default {
  data: () => ({
    //
  }),
};
</script>
