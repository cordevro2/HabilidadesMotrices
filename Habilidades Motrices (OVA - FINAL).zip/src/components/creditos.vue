<template>
  <v-container>
    <v-row align="center">
      <v-col class="pa-10"  cols="3">
        <v-avatar class="profile" color="cyan" size="164"  rounded>
          <v-img src="../assets/profile/isabela.jpeg"></v-img>
        </v-avatar>

        <v-col class="py-0">
          <v-list-item color="rgba(0, 0, 0, .9)">
            <v-list-item-content>
              <v-list-item-title class="title">
                Isabela Castellar.
              </v-list-item-title>
              <v-list-item-subtitle>Lic. Informatica</v-list-item-subtitle>
            </v-list-item-content>
          </v-list-item>
        </v-col>
      </v-col>

      <v-col align-self="start" class="pa-10"  cols="3">
        <v-avatar class="profile" color="grey" size="164"  rounded>
          <v-img src="../assets/profile/yarlis.jpeg"></v-img>
        </v-avatar>
        <v-col class="py-0">
          <v-list-item color="rgba(0, 0, 0, .4)">
            <v-list-item-content>
              <v-list-item-title class="title">
                Yarlis García
              </v-list-item-title>
              <v-list-item-subtitle>Lic. Informatica</v-list-item-subtitle>
            </v-list-item-content>
          </v-list-item>
        </v-col>
      </v-col>

      <v-col align-self="start" class="pa-10"  cols="3">
        <v-avatar class="profile" color="grey" size="164"  rounded>
          <v-img src="../assets/profile/jorge.jpeg"></v-img>
        </v-avatar>
        <v-col class="py-0">
          <v-list-item color="rgba(0, 0, 0, .4)">
            <v-list-item-content>
              <v-list-item-title class="title">
                Jorge Sierra
              </v-list-item-title>
              <v-list-item-subtitle>Lic. Informatica</v-list-item-subtitle>
            </v-list-item-content>
          </v-list-item>
        </v-col>
      </v-col>

      <v-col align-self="start" class="pa-10"  cols="3">
        <v-avatar class="profile" color="grey" size="164"  rounded>
          <v-img src="../assets/profile/gustavo.jpeg"
          ></v-img>
        </v-avatar>
        <v-col class="py-0">
          <v-list-item color="rgba(0, 0, 0, .4)">
            <v-list-item-content>
              <v-list-item-title class="title">
                Gustavo Vega
              </v-list-item-title>
              <v-list-item-subtitle>Lic. Informatica</v-list-item-subtitle>
            </v-list-item-content>
          </v-list-item>
        </v-col>
      </v-col>
    </v-row>

  
      <v-row justify="center">
        <v-col align="center" class="pa-0" cols="5">
          <v-avatar class="profile" color="cyan" size="164" rounded>
            <v-img src="../assets/profile/aly.jpg"></v-img>
          </v-avatar>
        <v-col class="py-0">
          <v-list-item color="rgba(0, 0, 0, .9)">
            <v-list-item-content>
              <v-list-item-title class="title">
                Aly Benhur Culchac De La Vega
              </v-list-item-title>
              <v-list-item-subtitle>Lic. Informatica/Programación</v-list-item-subtitle>
              <v-list-item-subtitle>TECNICAS AVANZADAS DE PROGRAMACION</v-list-item-subtitle>
            </v-list-item-content>
          </v-list-item>
        </v-col>
         </v-col>
      </v-row>

  </v-container>
</template>

<script>
export default {
  data: () => ({
    //
  }),
};
</script>
